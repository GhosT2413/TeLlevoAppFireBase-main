import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-carros',
  templateUrl: './listar-carros.page.html',
  styleUrls: ['./listar-carros.page.scss'],
})
export class ListarCarrosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
