import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestion-usuario',
  templateUrl: './gestion-usuario.page.html',
  styleUrls: ['./gestion-usuario.page.scss'],
})
export class GestionUsuarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
