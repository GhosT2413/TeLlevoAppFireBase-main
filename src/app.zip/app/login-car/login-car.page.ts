import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-car',
  templateUrl: './login-car.page.html',
  styleUrls: ['./login-car.page.scss'],
})
export class LoginCarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
